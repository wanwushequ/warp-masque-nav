﻿param(
    [int]$Count = 7
)

$UsquePath = Join-Path $PSScriptRoot "usque.exe"
$RandomId = -join ((48..57) + (97..122) | Get-Random -Count 8 | ForEach-Object { [char]$_ })
$TempDir = Join-Path $env:TEMP "warp-clash-$RandomId"

if (-not (Test-Path $UsquePath)) {
    Write-Error "usque.exe 未找到"
    exit 1
}

function Strip-PemHeaders {
    param([string]$PemContent)
    $lines = $PemContent -split "`n"
    $b64 = @()
    foreach ($line in $lines) {
        $trimmed = $line.Trim()
        if ($trimmed -and $trimmed -notlike '-----BEGIN*' -and $trimmed -notlike '-----END*') {
            $b64 += $trimmed
        }
    }
    return $b64 -join ''
}

function Format-YamlBool {
    param([bool]$Value)
    if ($Value) { return "true" } else { return "false" }
}

try {
    # 注册一次账号
    $configFile = "config-masque.json"
    $configPath = Join-Path $PSScriptRoot $configFile
    $needRegister = -not (Test-Path $configPath)

    if (-not $needRegister) {
        Write-Host "已有账号文件 $configFile，是否注册新账号？(y/n): " -NoNewline
        $input = Read-Host
        if ($input -eq 'y') {
            Remove-Item -Path $configPath -Force
            $needRegister = $true
        }
    }

    if ($needRegister) {
        Write-Host "注册新 Warp 账号..."
        $regOutput = & $UsquePath register -c $configPath --accept-tos 2>&1
        if (-not (Test-Path $configPath)) {
            Write-Host "`n注册输出:"
            $regOutput | ForEach-Object { Write-Host $_ }
            Write-Error "MASQUE 注册失败（请检查网络或稍后再试）"
            exit 1
        }
    }

    $cfg = Get-Content -Raw -Path $configPath | ConvertFrom-Json
    
    # 定义 7 个不同的 server
    $servers = @(
        "162.159.198.2",
        "162.159.199.2",
        "masque.bestcf.eu.cc",
        "masque1.bestcf.eu.cc",
        "masque2.bestcf.eu.cc",
        "162.159.198.1",
        "162.159.199.1"
    )

    Write-Host "生成 Clash 配置..."
    $null = New-Item -ItemType Directory -Path $TempDir -Force
    $yamlPath = Join-Path $TempDir "Clash-MASQUE-Temp.yaml"

    # 生成 proxies 列表（同一个账号，不同 server）
    $proxiesYaml = @()
    $proxyNames = @()
    for ($i = 1; $i -le $Count; $i++) {
        $name = "MASQUE$i - Masque.pages.dev"
        $proxyNames += $name
        $server = if ($i -le $servers.Count) { $servers[$i-1] } else { $servers[0] }
        
        $proxiesYaml += "  - name: $name"
        $proxiesYaml += "    type: masque"
        $proxiesYaml += "    server: $server"
        $proxiesYaml += "    port: 443"
        $proxiesYaml += "    ip: $($cfg.ipv4)"
        $proxiesYaml += "    ipv6: $($cfg.ipv6)"
        $proxiesYaml += "    private-key: $($cfg.private_key)"
        $proxiesYaml += "    public-key: $(Strip-PemHeaders -PemContent $cfg.endpoint_pub_key)"
        $proxiesYaml += "    mtu: 1280"
        $proxiesYaml += "    sni: www.microsoft.com"
        $proxiesYaml += "    congestion-controller: bbr"
        $proxiesYaml += "    udp: true"
        $proxiesYaml += "    remote-dns-resolve: true"
        $proxiesYaml += "    dns: [ 1.1.1.1, 8.8.8.8, 9.9.9.9 ]"
		$proxiesYaml += ""
    }

    # 构建 proxy 列表字符串
    $proxyListStr = $proxyNames -join ', '
    $autoProxies = "[$proxyListStr]"
    $manualProxies = "[自动选择, $proxyListStr]"

    $fullYaml = @"
mixed-port: 7890
allow-lan: true
bind-address: '*'
mode: rule
log-level: info
ipv6: false
unified-delay: true
tcp-concurrent: true
geodata-mode: true
geox-url:
  geoip: https://fastly.jsdelivr.net/gh/MetaCubeX/meta-rules-dat@release/geoip.dat
  geosite: https://fastly.jsdelivr.net/gh/MetaCubeX/meta-rules-dat@release/geosite.dat
geo-auto-update: true
geo-update-interval: 24
global-ua: clash.meta
hosts:
  dns.alidns.com: [223.5.5.5, 223.6.6.6, 2400:3200::1, 2400:3200:baba::1]
  doh.pub: [1.12.12.12, 120.53.53.53]
dns:
  enable: true
  listen: 0.0.0.0:1053
  cache-algorithm: arc
  enhanced-mode: redir-host
  prefer-h3: true
  ipv6: true
  respect-rules: true
  nameserver:
    - https://cloudflare-dns.com/dns-query#proxy=手动选择
  nameserver-policy:
    geosite:cn:
      - https://dns.alidns.com/dns-query
      - https://doh.pub/dns-query
  proxy-server-nameserver:
    - https://dns.alidns.com/dns-query
  fallback:
    - https://dns.alidns.com/dns-query
  fallback-filter:
    geoip: false
    ipcidr: []
    domain: []

proxy-groups:
  - name: 手动选择
    type: select
    proxies: $manualProxies
    icon: "https://raw.githubusercontent.com/Koolson/Qure/master/IconSet/Color/Proxy.png"
  - name: 自动选择
    type: url-test
    proxies: $autoProxies
    url: "http://cp.cloudflare.com/generate_204"
    interval: 300
    tolerance: 20
    icon: "https://raw.githubusercontent.com/Koolson/Qure/master/IconSet/Color/Auto.png"
  - name: 全球直连
    type: select
    proxies: [DIRECT]
    icon: "https://raw.githubusercontent.com/Koolson/Qure/master/IconSet/Color/Direct.png"
  - name: 全球拦截
    type: select
    proxies: [REJECT, 手动选择, 自动选择, DIRECT]
    icon: "https://raw.githubusercontent.com/Koolson/Qure/master/IconSet/Color/Reject.png"

rules:
  - GEOIP,private,DIRECT
  - GEOSITE,private,DIRECT
  - GEOSITE,category-ads-all,全球拦截
  - GEOSITE,gfw,手动选择
  - GEOSITE,cn,全球直连
  - GEOIP,CN,全球直连
  - MATCH,手动选择

proxies:
$($proxiesYaml -join "`n")
"@

    $fullYaml | Set-Content -Path $yamlPath -Encoding UTF8

    $localPath = Join-Path $PSScriptRoot "Clash-MASQUE-MetaCubeX.yaml"
    Copy-Item -Path $yamlPath -Destination $localPath -Force
    Write-Host "`n✅ 已生成 $Count 个 MASQUE 节点（同一账号，不同端点）"
    Write-Host "✅ 已保存到: $localPath`n"
} finally {
    if (Test-Path $TempDir) {
        Remove-Item -Path $TempDir -Recurse -Force -ErrorAction SilentlyContinue
    }
}