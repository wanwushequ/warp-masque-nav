@echo off
chcp 65001 >nul
title Cloudflare WARP MASQUE协议

setlocal enabledelayedexpansion

:: 检查并自动获取管理员权限
net session >nul 2>&1
if %errorLevel% neq 0 (
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

cd /d "%~dp0"

echo ---------------------------------------------
echo MASQUE一键启动代理脚本 v1.2b - YouTube@真香定律
echo ---------------------------------------------

echo [信息] 正在检查并关闭残留进程...
start /b usque.exe --help >nul 2>&1
timeout /t 1 /nobreak >nul
taskkill /f /im usque.exe >nul 2>&1
timeout /t 1 /nobreak >nul

if not exist "config.json" (
    echo [提示] 未发现账号配置文件config.json，正在注册Cloudflare WARP账号....
    echo y | usque.exe register
    echo [提示] 等待配置文件生成...
    set /a "wait_count=0"
    :wait_loop
    if exist "config.json" (
        echo [提示] 配置文件已生成，继续启动服务...
        goto :start_service
    )
    set /a "wait_count+=1"
    if !wait_count! geq 30 (
        echo [错误] 等待配置文件超时（30秒），请手动检查 config.json 是否生成
        pause
        exit /b
    )
    timeout /t 1 /nobreak >nul
    goto :wait_loop
)

:start_service
:: 设置默认参数
set "PORT=40001"
set "USERNAME="
set "PASSWORD="

:: 如果存在 socks5.ini，则读取覆盖默认值
if exist "socks5.ini" (
    for /f "usebackq tokens=2 delims== " %%i in (`findstr /i "port" "socks5.ini"`) do (
        set "PORT=%%i"
    )
    :: 读取 username
    for /f "usebackq tokens=2 delims== " %%i in (`findstr /i "username" "socks5.ini"`) do (
        set "USERNAME=%%i"
    )
    :: 读取 password
    for /f "usebackq tokens=2 delims== " %%i in (`findstr /i "password" "socks5.ini"`) do (
        set "PASSWORD=%%i"
    )
    echo [信息] 已加载 socks5.ini 配置
) else (
    echo [信息] 未找到 socks5.ini，使用默认配置：端口 40001，用户名和密码为空
)

if defined USERNAME if defined PASSWORD (
    echo [信息] 正在启动 SOCKS5 转发服务...
    echo [信息] 端口：%PORT%，用户名：%USERNAME%，密码：%PASSWORD%，socks5.ini中可修改
    echo [提示] 复制下方链接，导入v2rayN客户端中，请勿关闭本窗口
    echo [链接] socks://%USERNAME%:%PASSWORD%@127.0.0.1:%PORT%#MASQUE-%PORT%-YouTube真香定律
	echo ---------------------------------------------
    usque.exe socks -b 127.0.0.1 -p %PORT% -u %USERNAME% -w %PASSWORD%
) else (
    echo [信息] 正在启动 SOCKS5 转发服务...
    echo [信息] 端口：%PORT%，用户名和密码均为空，socks5.ini中可修改
    echo [提示] 复制下方链接，导入v2rayN等客户端中，请勿关闭本窗口
    echo [链接] socks://127.0.0.1:%PORT%#MASQUE-%PORT%-YouTube真香定律
	echo ---------------------------------------------
    usque.exe socks -b 127.0.0.1 -p %PORT%
)

if %errorLevel% neq 0 (
    echo [错误] 程序执行失败，错误代码：%errorLevel%
    pause
)

endlocal