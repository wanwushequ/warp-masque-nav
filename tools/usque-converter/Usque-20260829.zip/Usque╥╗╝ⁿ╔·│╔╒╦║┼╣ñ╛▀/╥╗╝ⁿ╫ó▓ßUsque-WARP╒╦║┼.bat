echo y | usque.exe register

pause
