@echo off
chcp 65001 >nul
powershell -ExecutionPolicy Bypass -File "%~dp0ConvertTo-WarpClash-Loyalsoldier.ps1"
echo.
pause
